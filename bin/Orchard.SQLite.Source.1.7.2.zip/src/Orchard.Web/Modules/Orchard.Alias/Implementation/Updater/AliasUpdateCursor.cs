﻿namespace Orchard.Alias.Implementation.Updater {
    public class AliasUpdateCursor : IAliasUpdateCursor {
        public int Cursor { get; set; }
    }
}