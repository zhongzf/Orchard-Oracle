﻿namespace Orchard.AntiSpam.Models {
    public enum SpamStatus {
        Spam,
        Ham
    }
}