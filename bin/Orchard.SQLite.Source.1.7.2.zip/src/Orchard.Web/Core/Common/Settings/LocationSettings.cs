﻿namespace Orchard.Core.Common.Settings {
    public class LocationSettings {
        public string Zone { get; set; }
        public string Position { get; set; }
    }
}