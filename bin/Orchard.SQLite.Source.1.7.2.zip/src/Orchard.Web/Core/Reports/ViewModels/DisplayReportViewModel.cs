﻿using Orchard.Reports;

namespace Orchard.Core.Reports.ViewModels {
    public class DisplayReportViewModel  {
        public Report Report { get; set; }
    }
}