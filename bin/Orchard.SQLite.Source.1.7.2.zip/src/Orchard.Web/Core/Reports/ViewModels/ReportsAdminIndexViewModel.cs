﻿using System.Collections.Generic;
using Orchard.Reports;

namespace Orchard.Core.Reports.ViewModels {
    public class ReportsAdminIndexViewModel  {
        public IList<Report> Reports { get; set; }
    }
}