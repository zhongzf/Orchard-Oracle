using Orchard.ContentManagement;

namespace Orchard.Core.Navigation.ViewModels {
    public class CreateMenuItemViewModel  {
        public MenuItemEntry MenuItem { get; set; }
    }
}