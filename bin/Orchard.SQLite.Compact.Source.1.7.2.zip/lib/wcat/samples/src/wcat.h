#ifndef _WCAT_H
#define _WCAT_H

#define WCATRESULT_ERROR            (-1)
#define WCATRESULT_SUCCESS          (0)
#define WCATRESULT_MORE_DATA_NEEDED (1)
#define WCATRESULT_NEXT_PACKET      (2)

#endif // define _WCAT_H
