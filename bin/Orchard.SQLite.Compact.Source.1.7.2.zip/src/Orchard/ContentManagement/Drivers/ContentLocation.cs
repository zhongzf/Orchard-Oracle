﻿namespace Orchard.ContentManagement.Drivers {
    public class ContentLocation {
        public string Zone { get; set; }
        public string Position { get; set; }
    }
}