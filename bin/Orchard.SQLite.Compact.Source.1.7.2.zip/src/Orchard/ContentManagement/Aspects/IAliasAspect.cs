﻿namespace Orchard.ContentManagement.Aspects {
    public interface IAliasAspect : IContent {
        string Path { get; }
    }
}
