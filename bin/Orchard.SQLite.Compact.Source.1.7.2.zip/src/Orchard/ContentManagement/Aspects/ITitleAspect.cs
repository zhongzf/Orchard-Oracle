﻿namespace Orchard.ContentManagement.Aspects {
    public interface ITitleAspect : IContent {
        string Title { get; }
    }
}
