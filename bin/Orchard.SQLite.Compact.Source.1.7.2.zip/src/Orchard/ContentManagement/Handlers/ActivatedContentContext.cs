namespace Orchard.ContentManagement.Handlers {
    public class ActivatedContentContext {
        public string ContentType { get; set; }
        public ContentItem ContentItem { get; set; }
    }
}