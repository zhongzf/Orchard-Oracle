namespace Orchard.ContentManagement.Handlers {
    public interface IContentFilter {
    }
}
