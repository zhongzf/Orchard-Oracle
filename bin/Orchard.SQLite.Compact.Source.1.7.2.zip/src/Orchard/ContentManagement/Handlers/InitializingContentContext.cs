﻿namespace Orchard.ContentManagement.Handlers {
    public class InitializingContentContext {
        public string ContentType { get; set; }
        public ContentItem ContentItem { get; set; }
    }
}