﻿using System;

namespace Orchard.Commands {
    [AttributeUsage(AttributeTargets.Property)]
    public class OrchardSwitchAttribute : Attribute {
    }
}
