﻿namespace Orchard.Caching {
    public interface IVolatileProvider : ISingletonDependency {
    }
}