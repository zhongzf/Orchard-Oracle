﻿using Orchard.Data.Migration;


namespace Orchard.Home
{
    public class Migrations : DataMigrationImpl
    {
        //public int Create()
        //{
        //    return 1;
        //}

        //public int UpdateFrom1()
        //{
        //    return 2;
        //}
    }
}