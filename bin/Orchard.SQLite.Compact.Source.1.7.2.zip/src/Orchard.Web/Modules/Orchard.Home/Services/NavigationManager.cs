﻿using Orchard.UI.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Orchard.Home.Services
{
    public class NavigationManager : INavigationManager
    {
        public IEnumerable<MenuItem> BuildMenu(string menuName)
        {
            return new List<MenuItem>();
        }

        public IEnumerable<MenuItem> BuildMenu(ContentManagement.IContent menu)
        {
            return new List<MenuItem>();
        }

        public IEnumerable<string> BuildImageSets(string menuName)
        {
            return new List<string>();
        }

        public string GetUrl(string menuItemUrl, System.Web.Routing.RouteValueDictionary routeValueDictionary)
        {
            return string.Empty;
        }

        public string GetNextPosition(ContentManagement.IContent menu)
        {
            return string.Empty;
        }
    }
}
