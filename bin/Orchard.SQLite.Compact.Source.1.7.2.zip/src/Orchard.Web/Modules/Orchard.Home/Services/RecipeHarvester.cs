﻿using Orchard.Recipes.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Orchard.Home.Services
{
    public class RecipeHarvester : IRecipeHarvester
    {
        public IEnumerable<Recipes.Models.Recipe> HarvestRecipes(string extensionId)
        {
            return new List<Recipes.Models.Recipe>();
        }
    }
}