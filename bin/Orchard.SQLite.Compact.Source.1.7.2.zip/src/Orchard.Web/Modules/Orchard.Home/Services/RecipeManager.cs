﻿using Orchard.Recipes.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Orchard.Home.Services
{
    public class RecipeManager : IRecipeManager
    {
        public string Execute(Recipes.Models.Recipe recipe)
        {
            return string.Empty;
        }
    }
}