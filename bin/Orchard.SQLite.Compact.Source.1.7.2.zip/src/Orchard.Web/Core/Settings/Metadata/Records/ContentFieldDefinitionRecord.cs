namespace Orchard.Core.Settings.Metadata.Records {
    public class ContentFieldRecord {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
    }
}
